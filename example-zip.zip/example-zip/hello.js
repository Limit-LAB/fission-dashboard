module.exports =
    /** @type {import("../env").Handler} */
    async (context) => {
        return context.text("Hello, Homo from zip!");
    };


module.exports = async (context) => {
    return {
        status: 200,
        body: "hello, world!\n"
    };
}
